# Javascript and React for absolute beginners

Let's learn about basics of JavaScript and React within 30 hours.

## Installation guide:

Follow the steps in this section to setup basic installation and IDE setup.

[Installation guide](/setup.md)

## Day wise lessons and code sample

- Day 1 - 