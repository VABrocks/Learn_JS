function ChangeContent(id,message){
    document.getElementById(id).innerHTML=message;
}