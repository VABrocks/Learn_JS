// // let a="ALL stdents will be here";
// // var b=70;
// // const pi=24;

// // console.log("message : "+a+", no. of students : "+b)
// // console.log(pi);
// // console.log(b);

// // let ussedata;
// //  isEqual = 5==="5"
// //  console.log(isEqual)

//  let name="Vivek";
// // a=`My name is $`name`;
// console.log(`My name is ${name}`)
// console.warn(name)
// console.log(`hello
//     my name is vivek`)

// let arr=[1,2,3]
// let obj=([{a:123,b:"456"},{a:123,b:"456"}])
// console.log(typeof(arr))
// console.log(typeof(obj))
// let a = 10;
// let b = 3;
// let sum = a+b;
// let diff = a-b;
// let product = a*b;
// let division = a/b;
// console.log(`Product: ${product}`);
// x=10;
// b=5
// x*=b;
// console.log(`X*=5 : ${x}`)
// console.log(typeof(a))

// let date=new Date();
// console.log(date)
// console.log(typeof(date))

// // alert("Welcome to Javascript course")
// // let myname=prompt("Whats your name:");
// // console.log(myname)

// console.table(obj);

// name=prompt("Enter you name: ")
// name=parseInt(name)

// workHours=prompt("Enter the work hours:");
// workHours=parseInt(workHours)
// switch (workHours) {
//     case 8:
//         console.log("Its 8 hours");
//         break;
//     case 10:
//         console.log("Its 10 hours");  
//         break;
//     default:
//         console.log("no work hours");
// }


// for (let i = 0; i <=5; i++){
//     console.log("Task "+ i + " Complete Panchayat Duty");
//     }
    
// let i=1;
// do{
//     console.log(i)
// i++
// }while(i<=5)

// arr=[1,2,3,4,5,6,7,8,9]
// for (let i in arr){
//     console.log(arr[i]);
    
// let a = {s:123,d:456,f:789}
// for (baa in a){
//     console.log(a[baa])
// }

// function greet(name){
// return `Hello ${name} Good Morning`
// }
// name=prompt("Enter your name")
// message=greet(name)
// console.log(message)

// let greet=function(name){
//     console.log(`Hello ${name} Good Morning`)
// }
// name=prompt("Enter your name")
// console.log(greet(name))

let greet=(name)=>{
    // console.log(`Hello ${name} Good Morning`)
    console.log("Hello "+ name + " Good Morning")
}
name=prompt("Enter your name" + "vvvi")
console.log(greet(name))
