let task={
    title:"Buy Groceries",
    dueDate:"2024-06-10",
    isCompleted:false

};

console.log(task);
console.log(task.title);
console.log(task["dueDate"]);


// task.priority=("High");
// console.log(task);

// task.isCompleted=true;
// console.log(task.isCompleted)

// delete task.dueDate;
// console.log(task.dueDate)

//  task={
//     title:"Buy groceries",
//     isCompleted:false,
//     toggleCompletion:function(){
//         this.isCompleted=!this.isCompleted;
//     }
// };
